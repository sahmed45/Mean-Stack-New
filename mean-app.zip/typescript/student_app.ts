//import ts students
import {StudentObject} from "./students"
let student1: StudentObject;
student1.firstName 