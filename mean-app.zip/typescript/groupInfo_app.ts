import { MemberObject } from "./groupInfo";
let member1: MemberObject;
member1.contact
member1.name