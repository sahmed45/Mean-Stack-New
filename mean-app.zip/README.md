# Item Inventory MEAN Stack

An Item inventory tracker created using the MEAN stack

Requirements:

MongoDB
nodejs
express
angular
